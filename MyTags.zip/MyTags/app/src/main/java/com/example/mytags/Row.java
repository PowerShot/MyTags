package com.example.mytags;

public class Row {

    private int img;

    public Row(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
